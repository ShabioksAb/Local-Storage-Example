function setCarrera()
{
	var c = document.getElementById("carreras");
	localStorage.setItem("v_carrera", c.value);
}
function getCarrera()
{
	var c = document.getElementById("carrera");
	c.value = localStorage.getItem("v_carrera");
}